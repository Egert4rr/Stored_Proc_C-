﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace TARge20.Controllers
{
    public class Search : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
