﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace TARge20.Controllers
{
    public class Search : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public partial class SearchPageWithoutDynamicSQL : System.Web.Ul.Page
        {
            protected void Page_Load(object sender, EventArgs e)
            { }

            protected void btnSearch_Click(object sender, EventArgs e)
            {
                string connectionStr = ConfigurationManager.ConnectionStrings["connectionStr"].ConnectionString;
                using(SqlConnetion con = new SqlConnetion(connectionStr))
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "spSearchEmployees";
                    cmd.CommandType = CommandType.StoredProcedure;

                    if(inputFirstname.Value.Trim()!="")
                    {
                        SqlParameter param = new SqlParameter("@FistName", inputFirstname.Value);
                        cmd.Parameters.Add(param);
                    }

                    if (inputLastname.Value.Trim() != "")
                    {
                        SqlParameter param = new SqlParameter("@LastName", inputLastname.Value);
                        cmd.Parameters.Add(param);
                    }

                    if (inputGender.Value.Trim() != "")
                    {
                        SqlParameter param = new SqlParameter("@Gender", inputGender.Value);
                        cmd.Parameters.Add(param);
                    }

                    if (inputSalary.Value.Trim() != "")
                    {
                        SqlParameter param = new SqlParameter("@Salary", inputSalary.Value);
                        cmd.Parameters.Add(param);
                    }

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    gvSearchResults.DataSource = rdr;
                    gvSearchResults.DataBind();
                }
            }
        }
    }
}
