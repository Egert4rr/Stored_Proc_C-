Declare @MyGuid UniqueIdentifier

if(@MyGuid is null)
Begin
	print 'Guid is null'
end
else
begin
	print 'Guid is not null'
end



Declare @MyGuid Uniqueidentifier

if(@MyGuid is null)
Begin
set @MyGuid = NEWID()
end

select @MyGuid



Declare @MyGuid uniqueidentifier
select ISNULL (@MyGuid,newId())


Select CAST(cast(0 as binary) as uniqueidentifier)
or 
select CAST (0x0 as uniqueidentifier)



Declare @MyGuid Uniqueidentifier
Set @MyGuid = '00000000-0000-0000-0000-000000000000'

if(@MyGuid = '00000000-0000-0000-0000-000000000000')
begin
print 'Guid is empty'
end
else
begin
print 'Guid is not Empty'
end


Declare @MyGuid Uniqueidentifier
Set @MyGuid = '00000000-0000-0000-0000-000000000000'

if(@MyGuid = CAST(0x0 as uniqueidentifier))
begin
print 'Guid is empty'
end
else
begin
print 'Guid is not Empty'
end


--____________________________________________________
-- D�naamiline SQL serverisis

create table employees
(
ID int primary key identity,
FirstName nvarchar(50),
LastName nvarchar(50),
Gender nvarchar(10),
Salary int
)
go


insert into employees values ('Mark','Hasting','Male',60000)
insert into employees values ('Steve','Pound','Male',45000)
insert into employees values ('Ben','Hoskins','Male',70000)
insert into employees values ('Phillip','Hasting','Male',45000)
insert into employees values ('Mary','Lambeth','Female',30000)
insert into employees values ('Valarie','Vikings','Female',35000)
insert into employees values ('John','Stanmore','Male',80000)



Create proc spSearchEmployees
@FirstName nvarchar(100),
@LastName nvarchar(100),
@Gender nvarchar(50),
@Salary int
as 
begin

Select * from employees where
(FirstName = @FirstName or @FirstName is null) and
(LastName = @LastName or @LastName is null) and
(Gender = @Gender or @Gender is null) and
(Salary = @Salary or @Salary is null)
end



Declare @sql nvarchar(1000)

Declare @params nvarchar(1000)

Set @sql = 'Select * from Employees where FirstName=@FirstName and LastName=@LastName'
set @params = '@FirstName nvarchar(100), @LastName nvarchar(100)'

Execute sp_executesql @sql, @params, @FirstName = 'Ben', @LastName = 'Hoskins'



--__________________________________________________________________________________________
--Joins (Kordamine)
Drop table tblemployees



create table tblDepartment
(
Id int primary key,
DepartmentName nvarchar(50),
Location nvarchar(50),
DepartmentHead nvarchar(50)
)
go

insert into tblDepartment values (1,'IT','London','Rick')
insert into tblDepartment values (2,'Payroll','Delhi','Ron')
insert into tblDepartment values (3,'HR','New York','Christie')
insert into tblDepartment values (4,'Other Department','Sydney','Cinderella')



create table tblEmployees
(
Id int primary key,
Name nvarchar(50),
gender nvarchar(50),
Salary int,
DepartmentId int foreign key references tblDepartment(Id)
)
go

insert into tblEmployees values (1,'Tom','Male',4000,1)
insert into tblEmployees values (2,'Pam','Female',3000,3)
insert into tblEmployees values (3,'John','Male',3500,1)
insert into tblEmployees values (4,'Sam','Male',4500,2)
insert into tblEmployees values (5,'Todd','Male',2800,2)
insert into tblEmployees values (6,'Ben','Male',7000,1)
insert into tblEmployees values (7,'Sara','Female',4800,3)
insert into tblEmployees values (8,'Valarie','Female',5500,1)
insert into tblEmployees values (9,'James','Male',6500,null)
insert into tblEmployees values (10,'Russel','Male',8800,null)



select name,gender,salary,departmentname
from tblEmployees
cross join tbldepartment


select name,gender,salary,departmentname
from tblEmployees
inner join tbldepartment
on tblEmployees.DepartmentId = tbldepartment.Id

--join ja inner join on sama, parem on kasutada inner joini kuna see t�psustab k�skluse paremini

select name,gender,salary,departmentname
from tblEmployees
join tbldepartment
on tblEmployees.DepartmentId = tbldepartment.Id




select name,gender,salary,departmentname
from tblEmployees
left outer join tbldepartment
on tblEmployees.DepartmentId = tbldepartment.Id


select name,gender,salary,departmentname
from tblEmployees
left join tbldepartment
on tblEmployees.DepartmentId = tbldepartment.Id



select name,gender,salary,departmentname
from tblEmployees
right outer join tbldepartment
on tblEmployees.DepartmentId = tbldepartment.Id

-- or

select name,gender,salary,departmentname
from tblEmployees
right join tbldepartment
on tblEmployees.DepartmentId = tbldepartment.Id




select name,gender,salary,departmentname
from tblEmployees
full outer join tbldepartment
on tblEmployees.DepartmentId = tbldepartment.Id

-- or

select name,gender,salary,departmentname
from tblEmployees
Full join tbldepartment
on tblEmployees.DepartmentId = tbldepartment.Id


--CROSS JOIN: tagastab k�ik omavahel olevad read
--INNER JOIN: Tagastab ainult kattuvad read
--LEFT JOIN: Tagastab kattuvad read ja k�ik mitte-kattuvad read vasakust tabelist
--RIGHT JOIN: Tagastab k�ik kattuvad read ja k�ik mitte-kaatuvad read paremast tabelist
--FULL JOIN: Tagastab vasakust ja paremast tabelist ja k�ik mitte kattuvad read


--__________________________________________________________________
--Stored proc veb otsingus


Alter proc spSearchEmployees
@FirstName nvarchar(100) = null,
@LastName nvarchar(100) = null,
@Gender nvarchar(50) = null,
@Salary int = null
as
begin
select * from employees where
(FirstName = @FirstName or @FirstName is null) and
(LastName = @LastName or @LastName is null) and
(Gender = @Gender or @Gender is null) and
(Salary = @Salary or @Salary is null)
End
go